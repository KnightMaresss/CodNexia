import { MongoClient } from 'mongodb'

if (!process.env.MONGODB_URI) {
  throw new Error('Please add your MongoDB URI to .env.local')
}

const uri = process.env.MONGODB_URI
const options = {}

let client: MongoClient
let clientPromise: Promise<MongoClient>

declare global {
  var _mongoClientPromise: Promise<MongoClient> | undefined
}

if (process.env.NODE_ENV === 'development') {
  if (!global._mongoClientPromise) {
    client = new MongoClient(uri, options)
    global._mongoClientPromise = client.connect()
      .catch((error) => {
        console.error('MongoDB connection failed:', error)
        throw new Error('Failed to connect to database. Please check your MongoDB connection.')
      })
  }
  clientPromise = global._mongoClientPromise
} else {
  client = new MongoClient(uri, options)
  clientPromise = client.connect()
    .catch((error) => {
      console.error('MongoDB connection failed:', error)
      throw new Error('Failed to connect to database. Please check your MongoDB connection.')
    })
}

export default clientPromise